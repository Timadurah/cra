<?php
	require 'notification.php';
    header("Location: ./cra.html");
?>
