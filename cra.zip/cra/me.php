<?php
$send="yahoo@yahoo.com"// your email address for result (!Urgentor)

?>
